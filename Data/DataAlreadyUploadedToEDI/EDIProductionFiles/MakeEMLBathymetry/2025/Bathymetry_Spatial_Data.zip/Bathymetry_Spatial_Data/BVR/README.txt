BVR Files

DONT_pub_BUTKEEP/Raw Data:
BVR_19APR2024 - data that was collected on 19 April 2024; contains 3 passes (000-002) each with a .PDO, GPS, and ASC file. These files must be stored in the same folder.

The data has been corrected for magnetic declination.

DeclinationData_BVR - lists declination as 8.89 degrees West, which should be input into WinRiver as -8.86.


VMT Processed Data:
BVR_14APR24_Reprocessed - excel file with data that has been processed in VMT. Includes ensemble number, Easting, Northing, and depth. 


BVR_outline, BVR_contours, BVR_watershed, BVR_features: all contain shapefiles for named feature of BVR
