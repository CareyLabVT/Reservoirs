FCR Files

DONT_pub_BUTKEEP/Raw Data:
FCR_6JUL2023 - data that was collected on 6 July 2023; contains 3 passes (000-002) each with a .PDO, GPS, and ASC file. These files must be stored in the same folder.
FCR_13JUL2023 - data that was collected on 13 July 2023; contains 3 passes (000-002) each with a .PDO, GPS, and ASC file. These files must be stored in the same folder.

Both sets of data have been corrected for magnetic declination.

DeclinationData_FCR - lists declination as 8.86 degrees West, which should be input into WinRiver as -8.86.


DONT_pub_BUTKEEP/VMT Processed Data:
FCR_6JUL23_Reprocessed - excel file with data that has been processed in VMT. Includes ensemble number, Easting, Northing, and depth. 
FCR_13JUL23_Reprocessed - excel file with data that has been processed in VMT. Includes ensemble number, Easting, Northing, and depth. 


FCR_outline, FCR_contours, FCR_watershed, FCR_features: all contain shapefiles for named feature of FCR

FCR_TIN_smooth_15_sooth50v2: This is the final TIN that was resmoothed to remove the EM bumps, previous version is in DONT_pub_BUTKEEP