FCR Files


VMT Processed Temp Corrected Data:
FCR_2023 - excel file with data that has been processed in VMT. Includes ensemble number, Easting, Northing, and depth. Data is corrected for both temperature and magnetic declanation. 


FCR_outline, FCR_contours, FCR_watershed, FCR_features: all contain shapefiles for named feature of FCR

FCR_TIN_smooth_15_sooth50v2: This is the final TIN file for FCR