BVR bathymetry files 


BVR_outline_fullpond: is the outline of BVR based on USGS national map
BVR_watershed: is the outline of the BVR watershed
BVR_bathy_shapefiles: folder containing shapefiles of BVR is 1-2 meter depth intervals when at full pond 


BVR_april_2024_bathymetry: contains files related to bathymetric mapping in BVR in April 2024 when BVR was approximately 10.5 meters deep when this ADCP data was collected, ~2.5m below full pond levels

BVR_april_2024_bathymetry/BVR_TIN: This is the final TIN file for BVR bathymetry from April 2024. Values are reported as meters elevation.

BVR_april_2024_bathymetry/BVR_bathymetry_raster: this folder contains a raster file version of BVR TIN. Values are reported as meters elevation. This version is provided for easier use in softwares other than ArcGIS Pro.


BVR_april_2024_bathymetry/VMT Processed Data:
BVR_14APR24_Reprocessed - csv file with data that has been processed in VMT. Includes ensemble number, Easting, Northing, and depth in meters. lat/long are in UTM 17N 