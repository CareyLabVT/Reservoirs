CCR Files

CCR_outline, CCR_watershed: all contain shapefiles for named feature of CCR
CCR_outline: is the outline of CCR
CCR_watershed: is the outline of the CCR watershed

CCR_TIN: this is the final TIN file for CCR bathymetry. Values are reported as meters elevation.

CCR_bathymetry_raster: this folder contains a raster file version of CCR TIN. Values are reported as meters elevation. This version is provided for easier use in softwares other than ArcGIS Pro.

CCR_bathymetry_XYZ_data/CCR_points_bath_UTM_meters.csv : this csv contains the lat, long, depth data used to generate CCR bathymetry files. lat/long are in projection UTM 17N. Depth is reported as elevation in meters. CCR surface elevation is equal to 1170 ft or 356.6 meters.