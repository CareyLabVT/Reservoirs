FCR Files


VMT Processed Temp Corrected Data:
FCR_2023 - csv file with data that has been processed in VMT. Includes ensemble number, Easting, Northing, and depth. Data is corrected for both temperature and magnetic declanation. 


FCR_outline, FCR_watershed, FCR_features: all contain shapefiles for named features of FCR
FCR_outline: is the outline of FCR
FCR_watershed: is the outline of the FCR watershed
FCR_features: folder containing shapefiles for various aspects of FCR including inflows and oxygenation systems

FCR_TIN: This is the final TIN file for FCR. Values are reported as meters elevation.

FCR_bathymetry_raster: this folder contains a raster file version of FCR TIN. Values are reported as meters elevation. This version is provided for easier use in softwares other than ArcGIS Pro.