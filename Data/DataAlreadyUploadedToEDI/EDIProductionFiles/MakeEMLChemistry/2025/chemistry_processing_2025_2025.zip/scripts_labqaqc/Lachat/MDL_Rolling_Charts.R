## MDL and Rolling Charts for QAQC: TNTP
## December 2025

# From Claude with Adrienne Breef-Pilz, Cayelan Carey, Frances Iannucci, and Katie Hoffman
# Created: 03 April 2026

# Edited: 21 May 2026
# Below is the prompt

#general idea: recreate graphs and calculations for each type of check standard/sample in the rolling charts excel file
#check standards to include: spiked blank, check 25, digest check, digested blanks
#other things: duplicates (rpd), spikes (% recovery)


#find a way to follow the same code below for duplicates and spike
#instead of calculating stats for peak area and concentration, calculate for Duplicates.RPD and Spikes.PctRecovery
#for now have it exclude anything flagged 8- will update with other criteria for exclusion later


#calculate statistics from the past two years of data: (did this)
#mean, sd, count of concentration
#t value needed for MDL calculation
#MDL and LOQ (spiked blanks, blanks, and check 25)
#mean and sd of peak area
#calculate other statistics for my own purposes
#repeat for full dataset and just for last two years (did this)
#mean percent recovery (mean/known), signal:noise (mean/sd), mean:MDL
#construct rolling charts plots in plotly: (check that this happens. I thought it already did)
#horizontal lines: mean, warning limits (mean +/-2sd), control limits (mean +/-3sd), expected conc (if known)
#scatter plot: x= row # and/or datetime, y= concentration (one plot for TN, one for TP)
#Pre-2024 lachat data won't have a time stamp though- only date.
#similar plot where y= peak area (no expected concentration)
#should end up with four plots total for check standards
#could also consider calculating and plotting percent recovery, but not critical
#give option to flag/omit bad points (this happens)
#make sure any flags also make it into the results for the individual run, not just the rolling charts.


# -------------------------------------------------------------------------
# Packages
# tidyverse / dplyr : data wrangling
# plotly            : interactive rolling charts
# purrr             : functional iteration (map, imap, walk)
# here              : portable file paths relative to the project root
# lubridate         : date arithmetic (%m-% for leap-year-safe subtraction)
# -------------------------------------------------------------------------
suppressPackageStartupMessages({
  library(tidyverse)
  library(dplyr)
  library(plotly)
  library(purrr)
  library(here)
  library(htmltools)
})


# Main function: run_mdl_rolling_charts
# Arguments:
#   df           - a single check standard data frame already in the global environment
#   analytes     - character vector of analytes to process, e.g. c("TN", "TP")
#   known        - named numeric vector of expected concentrations for percent recovery,
#                  e.g. c(TN = NA, TP = 25). A single unnamed value is recycled.
#   output_dir   - directory to write output files to
#   min_date     - optional Date; passed to compute_two_year_stats to clamp the
#                  rolling window start date. Use when a method change within the
#                  last 2 years means earlier data should be excluded,
#                  e.g. min_date = as.Date("2024-01-15"). NULL (default) = no clamp.
# Returns a named list (invisibly): checks, final_export, stats_with_roll,
#   mdl_summary, mdl_by_detection_date, and plots.

# Ucomment this when making this a function. 
run_mdl_rolling_charts <- function(
    df,
    #check,
    analytes    = c("TN", "TP"),
    known       = NA_real_,
    output_dir  = file.path(here::here(), "MDLs", "output"),
    min_date    = NULL,
    date_stamp = runDate # the date when you ran the latchet
) {
  
  # use this to run the script without making it a function. Use this for testing
  # add the data frame here
  # df = rc_digested.blanks
  # check = "water blank"
  # analytes = c("TP", "TN")
  #  known       = NA_real_
  # output_dir  = file.path(here::here(), "MDLs", "output")
  # min_date    = NULL
  # date_stamp = runDate
  
  
  working_dir <- here::here()
  if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
  
  # load functions
  source(file.path(working_dir, "functions/Lachat/append_flag_note.R"))
  source(file.path(working_dir, "functions/Lachat/Plotting_functions.R"))
  
  
  # Capture the name of the object passed as df (e.g. "check.25.standards")
  # and wrap it in a named list so imap can use the name as a label throughout
  # the pipeline (stored in the Check.Type column).
  check_label <- deparse(substitute(df))
  checks_to_use <- setNames(list(df), check_label)
  
  # get the name of the 
  
  ## Define the functions in this section that are used below. 
  # clean_checks()
  # Standardises column types for a single check-standard data frame and
  # stamps it with its check type label (e.g. "spiked.blanks").
  # Called via imap so check_type is supplied automatically from the list name.
  clean_checks <- function(df, check_type) {
    # uses `analytes` from the parent function's closure (e.g. c("TN","TP") or c("NH4","PO4","NO3"))
    result <- df %>%
      mutate(
        Check.Type     = check_type,
        Detection.Date = as.Date(Detection.Date),
        Observation    = as.integer(Observation),
        across(all_of(paste0("Conc.ugL.",  analytes)), as.numeric),
        across(all_of(paste0("Peak.Area.", analytes)), as.numeric)
      )
    # set values flagged as discard (flag 8) to NA
    for (a in analytes) {
      flag_col <- paste0("Flag.",     a)
      conc_col <- paste0("Conc.ugL.", a)
      peak_col <- paste0("Peak.Area.", a)
      if (flag_col %in% names(result)) {
        result[[conc_col]] <- ifelse(grepl("8", result[[flag_col]]), NA_real_, result[[conc_col]])
        result[[peak_col]] <- ifelse(grepl("8", result[[flag_col]]), NA_real_, result[[peak_col]])
      }
    }
    result
  }
  
  # compute_two_year_stats()
  # For every row i in df, looks back exactly 2 years from Detection.Date[i]
  # and computes the mean, SD, and n of all observations in that window.
  # Results are appended as new columns:
  #   mean_<Conc|Peak>_<analyte>_2yr
  #   sd_<Conc|Peak>_<analyte>_2yr
  #   n_<Conc|Peak>_<analyte>_2yr
  # The 2-year window uses lubridate::%m-% so leap days are handled correctly.
  #
  # Arguments:
  #   df       - check standard data frame
  #   analyte  - analyte name string, e.g. "TN"
  #   metric   - "concentration" or "peak_area"
  #   min_date - optional Date; if supplied, the rolling window start is
  #              clamped to this date. Use this when a method change within
  #              the 2-year lookback means earlier data should be excluded,
  #              e.g. min_date = as.Date("2024-01-15").
  #              NULL (default) applies no lower bound beyond the 2-year rule.
  #
  # TODO: exclude observations flagged as bad (flag 9 etc.) from the window.
  compute_two_year_stats <- function(df, analyte, metric = c("Conc.ugL", "Peak.Area"),
                                     min_date = NULL) {
    
    #this is so minor, but it would be nice to have calculated stats rounded to two decimal places
    #just have to figure out where to add in round(xxx, 2)
    
    #metric    <- match.arg(metric)
    value_col <- paste0(metric,".",analyte) 
    #print(value_col)
    flag_col  <- paste0("Flag.", analyte)
    
    # convert min_date once up front so we don't repeat the coercion inside the loop
    if (!is.null(min_date)) min_date <- as.Date(min_date)
    
    # sort by date so the rolling window is always well-defined
    out <- df
    out[[value_col]] <- as.numeric(out[[value_col]])
    out <- out %>% arrange(Detection.Date, Observation)
    
    n_rows <- nrow(out)
    means  <- rep(NA_real_,    n_rows)
    sds    <- rep(NA_real_,    n_rows)
    ns     <- rep(NA_integer_, n_rows)
    
    # Row-by-row loop: for each observation, define the 2-year window ending
    # on that row's detection date, then compute stats over the window.
    for (i in seq_len(n_rows)) {
      end_date   <- out$Detection.Date[i]
      # %m-% shifts back exactly 2 years, adjusting for leap days
      start_date <- as.Date(end_date) %m-% lubridate::years(2)
      
      # if a method-change date is supplied, use the later of the two starts
      # so that pre-change data are excluded from the window
      if (!is.null(min_date) && start_date < min_date) {
        start_date <- min_date
      }
      
      # subset to rows within the window
      window_df <- out %>%
        filter(
          Detection.Date <= end_date,
          Detection.Date > start_date
          #is.na(.data[[flag_col]])
          # TODO: exclude flag 9 (and other bad-data flags) rather than all flagged rows
        )
      
      # extract the target column and drop non-finite values
      vals <- window_df[[value_col]]
      vals <- vals[is.finite(vals)]
      
      ns[i]    <- length(vals)
      means[i] <- if (length(vals) > 0) mean(vals) else NA_real_
      sds[i]   <- if (length(vals) > 1) sd(vals)   else NA_real_
    }
    
    # Attach the rolling stats as new columns and return the updated data frame
    suffix <- metric
    out[[paste0("mean_", suffix, "_", analyte, "_2yr")]] <- means
    out[[paste0("sd_",   suffix, "_", analyte, "_2yr")]] <- sds
    out[[paste0("n_",    suffix, "_", analyte, "_2yr")]] <- ns
    out
  }
  
  # calc_mdl_summary()
  # Calculates summary statistics across the ENTIRE flagged dataset (not rolling)
  # for one or more analytes. Returns one row per analyte as a tibble.
  #
  # Statistics returned:
  #   n_obs          - number of finite observations
  #   mean_conc      - mean concentration (ug/L)
  #   sd_conc        - standard deviation of concentration
  #   t_value_99     - one-tailed t value at 99th percentile (df = n - 1)
  #   MDL            - Method Detection Limit  = t_99 * sd_conc
  #   LOQ            - Limit of Quantitation   = 10  * sd_conc
  #   mean_peak_area - mean instrument peak area
  #   sd_peak_area   - SD of peak area
  #   mdl_peak_area  - MDL calculated from peak area SD
  #   pct_recovery   - mean percent recovery = (mean_conc / known) * 100
  #   signal_noise   - signal-to-noise ratio  = mean_conc / sd_conc
  #   mean_mdl_ratio - mean_conc / MDL (how far the mean sits above the MDL)
  #
  # NOTE: known concentration should ideally live as a column in the data frame
  #       rather than as a function argument - flagged for future improvement.
  calc_mdl_summary <- function(df, analytes, known = NA_real_) {
    
    purrr::map_dfr(analytes, function(analyte) {
      
      # resolve known value for this analyte: use named entry if available, else recycle single value
      known_val <- if (length(known) > 1 && !is.null(names(known))) known[[analyte]] else known[[1]]
      
      conc_col <- paste0("Conc.ugL.", analyte)
      peak_col <- paste0("Peak.Area.", analyte)
      #keep <- is.finite(vals) #& is.na(df[[flag_col]]) &    #don't want it to remove all flagged values necessarily- depends on the flag
      
      vals      <- as.numeric(df[[conc_col]])
      peak_vals <- as.numeric(df[[peak_col]])
      # remove non-finite values (NA, NaN, Inf) before computing stats
      vals      <- vals[is.finite(vals)]
      peak_vals <- peak_vals[is.finite(peak_vals)]
      
      # calculations happen here
      n             <- length(vals)
      mean_conc     <- if (n > 0) mean(vals)              else NA_real_
      sd_conc       <- if (n > 1) sd(vals)                else NA_real_
      t_99          <- if (n > 1) qt(0.99, df = n - 1)   else NA_real_
      mdl           <- if (n > 1) t_99 * sd_conc          else NA_real_
      loq           <- if (n > 1) 10 * sd_conc            else NA_real_
      mean_peak     <- if (length(peak_vals) > 0) mean(peak_vals) else NA_real_
      sd_peak       <- if (length(peak_vals) > 1) sd(peak_vals)   else NA_real_
      mdl_peak      <- if (n > 1) t_99 * sd_peak          else NA_real_
      
      # mean percent recovery: (mean / known) * 100; NA if known is not supplied
      pct_recovery   <- if (!is.na(known_val) && known_val != 0) round(mean_conc / known_val * 100, 2) else NA_real_
      # signal:noise ratio: mean / sd
      signal_noise   <- if (!is.na(sd_conc) && sd_conc != 0) round(mean_conc / sd_conc, 2) else NA_real_
      # mean / MDL ratio
      mean_mdl_ratio <- if (!is.na(mdl) && mdl != 0) round(mean_conc / mdl, 2) else NA_real_
      
      tibble::tibble(
        Analyte        = analyte,
        n_obs          = n,
        mean_conc      = round(mean_conc, 2),
        sd_conc        = round(sd_conc, 2),
        t_value_99     = round(t_99, 4),
        MDL            = round(mdl, 2),
        LOQ            = round(loq, 2),
        mean_peak_area = round(mean_peak, 2),
        sd_peak_area   = round(sd_peak, 2),
        mdl_peak_area  = round(mdl_peak, 2),
        pct_recovery   = pct_recovery,
        signal_noise   = signal_noise,
        mean_mdl_ratio = mean_mdl_ratio
      )
    })
  }
  
  # compute_mdl_from_2yr_stats()
  # Adds per-row MDL/LOQ and quality statistics to df using the rolling 2-year
  # mean, SD, and n columns already added by compute_two_year_stats().
  # Each row's MDL/LOQ therefore reflects only the 2-year window ending on
  # that row's Detection.Date, giving a time-varying detection limit.
  #
  # New columns added (all suffixed _<analyte>_2yr):
  #   t99            - one-tailed t at 99th pct for the window's degrees of freedom
  #   MDL            - t99 * sd_conc
  #   LOQ            - 10  * sd_conc
  #   MDL_peak       - t99 * sd_peak
  #   pct_recovery   - (mean_conc / known) * 100
  #   signal_noise   - mean_conc / sd_conc
  #   mean_mdl_ratio - mean_conc / MDL
  compute_mdl_from_2yr_stats <- function(df, analyte, known = NA_real_) {
    n_conc_col    <- paste0("n_Conc.ugL_",    analyte, "_2yr")
    sd_conc_col   <- paste0("sd_Conc.ugL_",   analyte, "_2yr")
    mean_conc_col <- paste0("mean_Conc.ugL_",  analyte, "_2yr")
    sd_peak_col   <- paste0("sd_Peak.Area_",   analyte, "_2yr")
    mean_peak_col <- paste0("mean_Peak.Area_",  analyte, "_2yr")
    
    n_vals <- df[[n_conc_col]]
    
    # print(n_vals)
    t_vals <- ifelse(n_vals > 1, qt(0.99, df = n_vals - 1), NA_real_)
    
    mdl_vals  <- round(t_vals * df[[sd_conc_col]], 2)
    
    df %>%
      mutate(
        !!paste0("t99_",          analyte, "_2yr") := t_vals,
        !!paste0("MDL_",          analyte, "_2yr") := mdl_vals,
        !!paste0("LOQ_",          analyte, "_2yr") := round(10 * .data[[sd_conc_col]], 2),
        !!paste0("MDL_peak_",     analyte, "_2yr") := round(t_vals * .data[[sd_peak_col]], 2),
        # mean percent recovery: (mean_conc / known) * 100
        !!paste0("pct_recovery_", analyte, "_2yr") := ifelse(
          !is.na(known) & known != 0,
          round(.data[[mean_conc_col]] / known * 100, 2),
          NA_real_
        ),
        # signal:noise ratio: mean_conc / sd_conc
        !!paste0("signal_noise_", analyte, "_2yr") := ifelse(
          .data[[sd_conc_col]] != 0,
          round(.data[[mean_conc_col]] / .data[[sd_conc_col]], 2),
          NA_real_
        ),
        # mean / MDL ratio
        !!paste0("mean_mdl_ratio_", analyte, "_2yr") := ifelse(
          !is.na(mdl_vals) & mdl_vals != 0,
          round(.data[[mean_conc_col]] / mdl_vals, 2),
          NA_real_
        )
      )
  }
  
  
  # -------------------------------------------------------------------------
  # Helper function definitions
  # -------------------------------------------------------------------------
  
  # apply_flags_interactively()
  # Opens the data frame in the RStudio viewer, then prompts the user to
  # flag individual rows using append_flag_note() (from functions/).
  # Loops until the user answers "n", then returns the updated data frame
  # so flagged rows carry through to downstream stats and exports.
  #
  # TODO: update so it recalculates stats after flagging before exporting.
  apply_flags_interactively <- function(df, check_label) {
    cat("\nReviewing", check_label, "\n")
    cat("Rows available:", nrow(df), "\n")
    
    View(df) # open in RStudio viewer so rows are visible while answering prompts
    
    rl <- readline("Flag any rows in this check type? (y/n): ")
    while (tolower(rl) == "y") {
      rn        <- readline("Enter row number(s), comma or space separated: ")
      analyte   <- readline("Analyte(s) to flag (TN, TP): ")
      flag_num  <- as.numeric(readline("Enter numeric flag code: "))
      note_text <- as.character(readline("Enter note text: "))
      df <- append_flag_note(df = df, rn = rn, analyte = analyte, flag_num = flag_num, note_text = note_text)
      rl <- readline("Add more flags for this check type? (y/n): ")
    }
    df
  }
  
  # take out and put the date the latchet was run
  #date_stamp <- format(Sys.Date(), "%Y-%m-%d")
  
  # -------------------------------------------------------------------------
  # Step 1: clean the raw data
  # -------------------------------------------------------------------------
  checks_clean <- imap(checks_to_use, clean_checks)
  
  # -------------------------------------------------------------------------
  # Step 2: build initial plots from the cleaned data and save to preliminary_plots/
  #         so you can visually review before flagging anything
  # -------------------------------------------------------------------------
  plots_conc <- setNames(
    lapply(analytes, function(a) imap(checks_clean, ~build_rolling_plot(.x, analyte = a, metric = "Conc.ugL"))),
    paste0("plots_", tolower(analytes), "_conc")
  )
  plots_peak <- setNames(
    lapply(analytes, function(a) imap(checks_clean, ~build_rolling_plot(.x, analyte = a, metric = "Peak.Area"))),
    paste0("plots_", tolower(analytes), "_peak")
  )
  all_plots <- c(plots_conc, plots_peak)
  
  # each element of all_plots is itself a named list of plots (one per check type),
  # so flatten all plots into a single combined HTML file
  prelim_dir <- file.path(here::here(), "preliminary_plots")
  if (!dir.exists(prelim_dir)) dir.create(prelim_dir, recursive = TRUE)
  
  flat_plots <- list()
  for (plt_name in names(all_plots)) {
    plt_list <- all_plots[[plt_name]]
    for (check_name in names(plt_list)) {
      key <- paste0(plt_name, "_", gsub("[^A-Za-z0-9_.-]", "_", check_name))
      flat_plots[[key]] <- plt_list[[check_name]]
    }
  }
  
  # Build one self-contained HTML: save each widget to a temp file with all JS
  # inlined (selfcontained = TRUE), then combine: take the <head> from the
  # first file (contains all plotly/htmlwidgets JS embedded once) and the
  # <body> content (div + JSON data) from every file.
  html_file <- file.path(prelim_dir, paste0("Preliminary_Plots_", check_label, date_stamp, ".html")) # add the standard
  
  tmp_files <- lapply(flat_plots, function(plt) {
    f <- tempfile(fileext = ".html")
    htmlwidgets::saveWidget(plt, file = f, selfcontained = TRUE)
    f
  })
  
  html_contents <- lapply(tmp_files, readLines, warn = FALSE)
  
  # <head> (with all JS/CSS inlined) from the first plot is enough for all plots
  first    <- html_contents[[1]]
  head_end <- which(grepl("</head>", first, fixed = TRUE))[1]
  combined <- c(first[seq_len(head_end)], "<body>")
  
  # append each plot's <body> content (div + JSON)
  for (html in html_contents) {
    body_start <- which(grepl("<body",  html, fixed = TRUE))[1]
    body_end   <- which(grepl("</body>", html, fixed = TRUE))[1]
    if (!is.na(body_start) && !is.na(body_end) && body_end > body_start) {
      combined <- c(combined, html[(body_start + 1L):(body_end - 1L)])
    }
  }
  combined <- c(combined, "</body>", "</html>")
  
  writeLines(combined, html_file)
  file.remove(unlist(tmp_files))
  message("Preliminary plots saved to: ", html_file)
  
  # -------------------------------------------------------------------------
  # Step 3: interactive flagging of the cleaned data
  # -------------------------------------------------------------------------
  
  # add in a row.numbers column and then remove it after than values have been flagged
  
  checks_clean[[1]] <- checks_clean[[1]] |>
    mutate(row.numbers = row_number())
  
  flagged_checks <- imap(checks_clean, apply_flags_interactively)
  
  # Then remove any points flagged as 8. Change later so it is flexible for any analyte
  
  # Build analyte pattern dynamically for flexible handling of any analytes
  analyte_pattern <- paste(analytes, collapse = "|")
  
  flagged_checks[[1]] <- flagged_checks[[1]] |> 
    pivot_longer(cols = matches(paste0("\\.(", analyte_pattern, ")$")),
                 names_to = c(".value", "analyte"),
                 names_pattern = paste0("^(.+)\\.(" , analyte_pattern, ")$")) |>
    mutate(Peak.Area = ifelse(grepl("8", Flag), NA, Peak.Area),
           Conc.ugL = ifelse(grepl("8", Flag), NA, Conc.ugL)) |>
    pivot_wider(names_from = analyte,
                names_sep = ".",
                values_from = c(Peak.Area, Conc.ugL, Flag, Notes)) |>
    select(-row.numbers)
  
  
  
  print("Completed step 3")
  # -------------------------------------------------------------------------
  # Step 4: compute rolling 2-year stats on the flagged data
  # min_date is forwarded so the window can be clamped at a method-change date
  # -------------------------------------------------------------------------
  stats_with_roll <- flagged_checks %>%
    imap(function(df, nm) {
      result <- df
      for (a in analytes) {
        result <- result %>%
          compute_two_year_stats(analyte = a, metric = "Conc.ugL", min_date = min_date) %>%
          compute_two_year_stats(analyte = a, metric = "Peak.Area",     min_date = min_date)
      }
      result %>% mutate(Check.Type = nm)
    })
  
  print("complete step 4")
  # -------------------------------------------------------------------------
  # Step 5: MDL/LOQ summary across the full flagged dataset
  # calc_mdl_summary() uses ALL rows (not the rolling window) so this gives
  # an overall snapshot rather than a time-varying estimate.
  # TODO: add option to restrict to a custom date range or the last 2 years only.
  # TODO: if a method change falls within the 2-year window, allow a custom
  #       start date so pre-change data are excluded
  #       (e.g. "if start_date < method_change_date, set start_date = method_change_date").
  # -------------------------------------------------------------------------
  
  mdl_summary <- imap_dfr(stats_with_roll, function(df, nm) {
    calc_mdl_summary(df, analytes = analytes, known = known) %>%
      mutate(Check.Type = nm, .before = 1)
  })
  
  print("complete step 5")
  # -------------------------------------------------------------------------
  # Step 6: per-observation MDL/LOQ from the rolling 2-year window
  # -------------------------------------------------------------------------
  
  # Data frame of MDL and LOQ calculated from the last two years at each detection date.
  # One row per observation; MDL/LOQ reflect only the 2-year window ending on Detection.Date.
  mdl_by_detection_date <- imap_dfr(stats_with_roll, function(df, nm) {
    for (a in analytes) {
      known_val <- if (length(known) > 1 && !is.null(names(known))) known[[a]] else known[[1]]
      df <- compute_mdl_from_2yr_stats(df, a, known = known_val)
    }
    purrr::map_dfr(analytes, function(a) {
      df %>%
        transmute(
          Check.Type,
          Detection.Date,
          Observation,
          Analyte       = a,
          n_2yr           = .data[[paste0("n_Conc.ugL_",         a, "_2yr")]],
          mean_conc_2yr   = round(.data[[paste0("mean_Conc.ugL_",  a, "_2yr")]], 2),
          sd_conc_2yr     = round(.data[[paste0("sd_Conc.ugL_",    a, "_2yr")]], 2),
          t_value_99      = round(.data[[paste0("t99_",         a, "_2yr")]], 4),
          MDL             = .data[[paste0("MDL_",         a, "_2yr")]],
          LOQ             = .data[[paste0("LOQ_",         a, "_2yr")]],
          mean_peak_2yr   = round(.data[[paste0("mean_Peak.Area_",   a, "_2yr")]], 2),
          sd_peak_2yr     = round(.data[[paste0("sd_Peak.Area_",     a, "_2yr")]], 2),
          MDL_peak        = .data[[paste0("MDL_peak_",    a, "_2yr")]],
          pct_recovery    = .data[[paste0("pct_recovery_", a, "_2yr")]],
          signal_noise    = .data[[paste0("signal_noise_", a, "_2yr")]],
          mean_mdl_ratio  = .data[[paste0("mean_mdl_ratio_", a, "_2yr")]]
        )
    })
  }) %>%
    arrange(Check.Type, Analyte, Detection.Date, Observation)
  
  # remove duplicate rows (excluding Observation column)
  wer <- mdl_by_detection_date |>
    select(-Observation) |>
    unique()
  
  print("complete step 6")
  #write.csv(wer, "test_mdl_2_year_for_detection.csv", row.names = F)
  
  # -------------------------------------------------------------------------
  # Step 7: export
  # Three files are written to output_dir, each date-stamped:
  #   *_with_stats_<date>.csv   - full flagged data with rolling stats columns
  #   MDL_LOQ_summary_<date>.csv - one-row-per-analyte overall MDL/LOQ table
  #   *_with_stats_<date>.RData  - R objects for downstream use
  #
  # Publication note: MDL and LOQ for data products should be taken from the
  # spiked blank, calculated from the 2 years prior to the run date
  # (use mdl_by_detection_date for per-run values).
  # CCC also wants MDL/LOQ recorded for every individual run - the
  # mdl_by_detection_date output supports this directly.
  # -------------------------------------------------------------------------
  
  final_export <- bind_rows(flagged_checks) %>%
    arrange(Check.Type, Detection.Date, Observation)
  
  analyte_tag <- paste(analytes, collapse = "_")
  csv_out       <- file.path(output_dir, paste0("Rolling_Checks_",      analyte_tag, "_with_stats_", date_stamp, ".csv"))
  stats_out     <- file.path(output_dir, paste0("MDL_LOQ_summary_",     analyte_tag, "_",            date_stamp, ".csv"))
  rdata_out     <- file.path(output_dir, paste0("Rolling_Checks_",      analyte_tag, "_with_stats_", date_stamp, ".RData"))
  summary_2year <- file.path(output_dir, paste0("MDL_LOQ_summary_2year_",analyte_tag, "_",           date_stamp, ".csv"))
  
  write.csv(final_export, csv_out,   row.names = FALSE)
  write.csv(mdl_summary,  stats_out, row.names = FALSE)
  write.csv(wer, summary_2year, row.names = FALSE) # export the per-run MDL/LOQ table as well for reference
  save(final_export, mdl_summary, all_plots, file = rdata_out)
  
  message("Export complete:")
  message(" - Data with rolling stats: ", csv_out)
  message(" - MDL/LOQ summary:         ", stats_out)
  message(" - RData bundle:            ", rdata_out)
  
  # Line 573 is invisible(list(...)) — it returns all the computed results as a named list but suppresses auto-printing, 
  #so calling run_mdl_rolling_charts(...) without assigning the output doesn't flood the console. 
  # If you assign it (e.g. result <- run_mdl_rolling_charts(...)), you get full access to every object inside.
  invisible(list(
    checks                = flagged_checks,
    final_export          = final_export,
    stats_with_roll       = stats_with_roll,
    mdl_summary           = mdl_summary,
    mdl_by_detection_date = mdl_by_detection_date,
    plots                 = all_plots
  ))
  
  # return the flagged data frame. Is this necessary? 
  return(final_export)
  
  print("Finished checking the Rolling chart")
}
