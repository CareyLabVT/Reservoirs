# A function that makes a plotly plot with warning lines based on one or two SD
# Author: From MDL_Rolling_Charts_TNTP modified by Adrienne Breef-Pilz
# Date: 21 May 2026


calc_plot_limits <- function(df, analyte, y_col, reference_obs = NULL) {
  flag_col <- paste0("Flag.", analyte)
  
  if (is.null(reference_obs)) {
    reference_obs <- max(df$Observation, na.rm = TRUE)
  }
  
  # locate the reference row to anchor the date window
  ref_row <- df %>%
    filter(Observation == reference_obs) %>%
    slice(1)
  
  if (nrow(ref_row) == 0 || is.na(ref_row$Detection.Date[1])) {
    return(list(mean = NA_real_, warn_low = NA_real_, warn_high = NA_real_, ctl_low = NA_real_, ctl_high = NA_real_))
  }
  
  end_date   <- ref_row$Detection.Date[1]
  start_date <- as.Date(end_date) %m-% lubridate::years(2)
  
  # pull values strictly before the reference date (excludes the run being reviewed)
  vals <- df %>%
    filter(
      Detection.Date < end_date,
      Detection.Date >= start_date
      #is.na(.data[[flag_col]])
      # TODO: exclude bad flags before computing limits
    ) %>%
    pull(.data[[y_col]]) %>%
    as.numeric()
  
  vals <- vals[is.finite(vals)]
  mu   <- if (length(vals) > 0) mean(vals) else NA_real_
  sig  <- if (length(vals) > 1) sd(vals)   else NA_real_
  
  list(
    mean      = mu,
    warn_low  = mu - 2 * sig,   # warning limit: flag for investigation
    warn_high = mu + 2 * sig,
    ctl_low   = mu - 3 * sig,   # control limit: flag as out-of-control
    ctl_high  = mu + 3 * sig
  )
}




build_rolling_plot <- function(df, analyte, metric = c("Conc.ugL", "Peak.Area"), reference_obs = NULL) {
  
  check_label <- deparse(substitute(df))
  checks_to_use <- setNames(list(df), check_label)
  
  #metric  <- match.arg(metric)
  y_col   <- paste0(metric, ".",analyte) 
  y_title <- metric
  lims    <- calc_plot_limits(df, analyte, y_col, reference_obs = reference_obs)
  
  df[[y_col]] <- as.numeric(df[[y_col]])
  
  p <- ggplot2::ggplot(df, ggplot2::aes(
    x     = Observation,
    y     = .data[[y_col]],
    #color = Check.Type,
    text  = paste0(
      "Obs: ", Observation,
      "<br>Date: ", Detection.Date,
      #"<br>Check: ", Check.Type,
      "<br>Value: ", signif(.data[[y_col]], 5)
    )
  )) +
    ggplot2::geom_point(size = 2) +
    ggplot2::labs(
      title = paste("Rolling", toupper(metric), "Chart -", analyte, check_label),
      x     = "Observation Number",
      y     = y_title
    ) +
    ggplot2::theme_bw()
  
  if (is.finite(lims$mean)) {
    p <- p +
      ggplot2::geom_hline(yintercept = lims$mean,      color = "black",     linetype = "solid",  linewidth = 0.8) +
      ggplot2::geom_hline(yintercept = lims$warn_low,  color = "goldenrod", linetype = "dotted", linewidth = 0.8) +
      ggplot2::geom_hline(yintercept = lims$warn_high, color = "goldenrod", linetype = "dotted", linewidth = 0.8) +
      ggplot2::geom_hline(yintercept = lims$ctl_low,   color = "firebrick", linetype = "dashed", linewidth = 0.8) +
      ggplot2::geom_hline(yintercept = lims$ctl_high,  color = "firebrick", linetype = "dashed", linewidth = 0.8)
  }
  
  plotly::ggplotly(p, tooltip = "text", height = 500, width = NULL)
}


