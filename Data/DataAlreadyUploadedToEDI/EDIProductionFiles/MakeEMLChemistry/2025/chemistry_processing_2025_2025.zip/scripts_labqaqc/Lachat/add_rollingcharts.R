# Title: add_rollingcharts.R - add new observations to the rolling charts
# This scripts cleans the checks from the qc_check.R and adds them to the rolling chart
# Author: A. Breef-Pilz
# Date: 12 Mar 2026

add_rollingcharts <- function(
  data_file = data_list[[2]],  
  rolling_chart){
  
  # get the check from the list of returned data frames
  wb_check <- data_file |>
    select(-row.numbers)|>
    mutate(Observation = NA,
           Detection.Time = as.character(Detection.Time),
           across(starts_with("Flag."),  as.character),
           across(starts_with("Notes."), as.character))
  
  # ensure flag/notes columns in the rolling chart are character type (works for TN/TP and NH4/PO4/NO3)
  rolling_chart <- rolling_chart |>
    mutate(across(starts_with("Flag."),  as.character),
           across(starts_with("Notes."), as.character))
  
  # check if there are blanks already in the rolling file
  
  if(unique(wb_check$Detection.Date) %in% rolling_chart$Detection.Date){
    # decide if you want to over ride it
    rl= readline('It looks like you are reprocessing files because these dates are already in the rolling file. Would you like to keep the new checks or the old checks? (new/old): ')
    
    if(rl == "new"){
      
      rolling_chart2 <- rolling_chart|>
        filter(Detection.Date!=unique(wb_check$Detection.Date))|>
        bind_rows(wb_check)|>
        arrange(Detection.Date)|>
        mutate(Observation = seq(1:nrow(rolling_chart)))
      
      print("Removed the old checks and replaced with the new checks.")
      
    } else if(rl == "old"){
      
      rolling_chart2 <- rolling_chart
      print("Did not add the new checks.")
    }
  }else{
    # add it to the end
    rolling_chart2 <- bind_rows(rolling_chart, wb_check)
    
    # reorder and then add sequential order of numbers
    rolling_chart2 <- rolling_chart2|>
      arrange(Detection.Date)|>
      mutate(Observation = seq(1:nrow(rolling_chart2)))
    
    print("Added to rolling chart")
  }
  
  # return the updated rolling chart
  
  return(rolling_chart2)
}
