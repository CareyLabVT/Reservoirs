# Title: append_flag_note function
# helper to append notes/flags for one analyte
# Author: A.Breef-Pilz with help from Claude code
# Date: 12 March 2026
# Edit: 30 Jun 2026 - added an if statement to change change the give more flexibility to the analyte name

append_flag_note <- function(df, rn, analyte, flag_num = NA, note_text = NA) {
  
  
  # fix the row numbers and the list of analyte names here
  
  # accept a numeric vector/sequence (e.g. c(1,2,3) or 1:5) or a character string
  if (is.numeric(rn) || is.integer(rn)) {
    row_vector_rn <- as.numeric(rn)
  } else {
    # clean up and make it a vector if more than one row to exclude
    cleaned_string_rn <- gsub(",", " ", rn)
    # Split the string by one or more spaces and convert the elements to numeric,
    # expanding any colon-range tokens (e.g. "1:5" -> c(1,2,3,4,5))
    tokens <- unlist(strsplit(trimws(cleaned_string_rn), "\\s+"))
    row_vector_rn <- as.numeric(unlist(lapply(tokens, function(tok) {
      if (grepl("^\\d+:\\d+$", tok)) {
        bounds <- as.integer(unlist(strsplit(tok, ":")))
        seq(bounds[1], bounds[2])
      } else {
        as.numeric(tok)
      }
    })))
  }
  
  
  # make a whole bunch of if statements for fixing different ways to type TNTP. 
  # Probably need to find something better for the solubles. 
  if(analyte == "TNTP"|analyte == "TPTN"|analyte == "tntp"|analyte == "tn, tp"|analyte == "tp, tn"){
    analyte = "TN, TP"
  } else if( analyte == "tn"){
    analyte = "TN"
  } else if(analyte == "tp"){
    analyte = "TP"
  }
  
  
  
  # make into a character vector
  vare <- gsub(",", " ", analyte)
  name_vec <- as.character(unlist(strsplit(vare, "\\s+")))
  
  
  for(i in 1:length(name_vec)){
    
    flag_col <- paste0("Flag.", name_vec[i])
    note_col <- paste0("Notes.", name_vec[i])
    
    if (!is.na(flag_num)) {
      df[[flag_col]][df$row.numbers %in% row_vector_rn] <- ifelse(
        !is.na(df[[flag_col]][df$row.numbers %in% row_vector_rn]),
        paste(df[[flag_col]][df$row.numbers %in% row_vector_rn], flag_num),
        flag_num
      )
    }
    
    if (!is.na(note_text)) {
      df[[note_col]][df$row.numbers %in% row_vector_rn] <- ifelse(
        !is.na(df[[note_col]][df$row.numbers %in% row_vector_rn]),
        paste(df[[note_col]][df$row.numbers %in% row_vector_rn], "/", note_text),
        note_text
      )
    }
    
  } # end for loop
  
  return(df)
}
