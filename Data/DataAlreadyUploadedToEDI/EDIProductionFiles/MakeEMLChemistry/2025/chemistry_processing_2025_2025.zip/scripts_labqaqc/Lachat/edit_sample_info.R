# Title: edit_sample_info function
# helper to change Sample.ID and/or Cup.Number for specified rows
# Author: A.Breef-Pilz with help from GitHub Copilot
# Date: 16 April 2026

edit_sample_info <- function(df, rn, new_sample_id = NA, new_cup_number = NA) {
  
  # accept a numeric vector/sequence (e.g. c(1,2,3) or 1:5) or a character string
  if (is.numeric(rn) || is.integer(rn)) {
    row_vector_rn <- as.numeric(rn)
  } else {
    # clean up and make it a vector if more than one row
    cleaned_string_rn <- gsub(",", " ", rn)
    row_vector_rn <- as.numeric(unlist(strsplit(cleaned_string_rn, "\\s+")))
  }
  
  if (!is.na(new_sample_id)) {
    df$Sample.ID[df$row.numbers %in% row_vector_rn] <- new_sample_id
  }
  
  if (!is.na(new_cup_number)) {
    df$Cup.Number[df$row.numbers %in% row_vector_rn] <- new_cup_number
  }
  
  return(df)
}
