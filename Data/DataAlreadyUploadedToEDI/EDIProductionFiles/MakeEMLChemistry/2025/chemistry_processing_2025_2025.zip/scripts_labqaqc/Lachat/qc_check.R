# make a function to review quality checks
# the check names should be water blank, bisulfate blank, digest check, spiked blank, check standards
# Edit: 12 Mar 2026 - the qc_check returned with the data frame, made it flexible for totals and solubles
# 30 Jun 2026 - changed the filter for the check standards so it is from the Sample.Type column and not the Sample.ID column

qc_check <- function(
    lachat_data = data,
    analyte = analytes, 
    check){
  
  # lachat_data <- data_blank
  # check = "spiked blank"
  # analyte = analytes
  
  # make the columns for the Analytes we have 
  
  analy_col <- c("Peak.Area.", "Conc.ugL.", "expected.conc.", "Notes.", "Flag.")
  
  we <- unlist(lapply(analy_col, paste0, analyte))
  
  
  
  # have to have a grepel if statement to capture all the different options 
  
  if(check %in% 'water blank'){
    
    if(any(c("TN", "TP") %in% analyte)){
      
      # pattern for water blank for totals
      all_name <- "wa.*bla"
    } else{
      # pattern for water blank for solubles
      all_name <- "^B|^b|wa.*bla"
    }
    
  }else if(check %in% 'digest check'){
    
    all_name <- 'di.*ch'
    
  }else if(check %in% 'spiked blank'){
    
    all_name <- "sp.*bla"
    
  }else if(check %in% 'check standards'){
    all_name <- "chk|che.*[0-9]"
    
  } else{
    warning("Make sure you have the right check argument. The options are: water blank, digest check, spiked blank, check standards.")
  }
  
  # filter the data frame differently for the dups check and the spike recovery
  
  qc_stats <- lachat_data|>
    filter(grepl(all_name, Sample.ID,ignore.case = T) & Cup.Number!="S3")|>
    select(row.numbers, Detection.Date, Detection.Time, Sample.ID, Cup.Number, we)
  
  # For the soluble blank filter by Cup.Number because there was a sample labeled blank from 41. 
        #not sure about this approach- I still want to see the blanks with incorrect cup numbers so that I can flag them.
  
  if(any(c("NH4", "PO4", "NO3") %in% analyte) & check %in% 'water blank'){
    qc_stats <- qc_stats|>
      filter(Cup.Number %in% "S6")
  }
  
  # For check standards filter the data frame by Sample.Type instead of Sample.ID
  
  if(check %in% 'check standards'){
    qc_stats <- lachat_data |>
      filter(grepl("che", Sample.Type, ignore.case = T))|>
      select(row.numbers, Detection.Date, Detection.Time, Sample.ID, Cup.Number, we)
  }
  
  # for checked standards there is a little more that needs to happen
  if(check %in% 'check standards'){
    
    for(a in analyte){
      
      # check the standards
      # use the expected concentration compared to the actual concentration and for loop over the analytes
      qc_stats[,paste0("CheckStds.RPD.",a)] <-  
        round(((qc_stats[paste0("Conc.ugL.",a)] - qc_stats[paste0("expected.conc.",a)])/
                 qc_stats[paste0("expected.conc.",a)]) *100, 1)
      
    }
    
    # change the infinite values to NA
    qc_stats[sapply(qc_stats, is.infinite)] <- NA
    
  }else if(check %in% 'spiked blank'){
    
    # add the expected concentration
    
    # calculate the expected concentration for the spiked blank
    
    ### Frances check that the expected concentrations are correct for solubles
    
    if(any(c("TN", "TP") %in% analyte)){
      
      qc_stats <- qc_stats|>
        mutate(expected.conc.TP = round((sb.std*sb.conc)/(sb.std+sb.di),2),
               expected.conc.TN = expected.conc.TP*10,
               RPD.SB.TP = round(((Conc.ugL.TP - expected.conc.TP)/expected.conc.TP) * 100, 1),
               RPD.SB.TN = round(((Conc.ugL.TN - expected.conc.TN)/expected.conc.TN) * 100, 1))
      
    } else if(any(c("NH4", "PO4", "NO3") %in% analyte)){
      
      qc_stats <- qc_stats|>
        mutate(expected.conc.NH4 = round((sb.std*sb.conc)/(sb.std+sb.di),2),
               expected.conc.PO4 = round((sb.std*sb.conc)/(sb.std+sb.di),2),
               expected.conc.NO3 = round((sb.std*sb.conc)/(sb.std+sb.di),2),
               RPD.SB.NH4 = round(((Conc.ugL.NH4 - expected.conc.NH4)/expected.conc.NH4) * 100, 1),
               RPD.SB.PO4 = round(((Conc.ugL.PO4 - expected.conc.PO4)/expected.conc.PO4) * 100, 1),
               RPD.SB.NO3 = round(((Conc.ugL.NO3 - expected.conc.NO3)/expected.conc.NO3) * 100, 1))
      
    }
    
  }
  
  # Print the stats
  
  # make a for loop to go through the analytes 
  
  for(a in analyte){
    
    # water blanks
    print(paste0(a, " stats:"))
    
    print(summary(qc_stats[,paste0("Conc.ugL.",a)]))
    
    
    # print the mean of digestion checks
    
    if(check %in% 'digest check'){
      
      rt <- unlist(c(qc_stats[paste0("Conc.ugL.",a)]))
      
      if(a == "TP"){
        # get the column of the data, make it a list and then unlist it. Probably a better way to do this. 
        
        
        print(paste('percent difference from expected = ', 
                    round(((mean(rt, na.rm = T)-40)/40)*100, 1)))
        
      } else if(a == "TN"){
        
        print(paste('percent difference from expected = ', round(((mean(rt, na.rm = T)-400)/400)*100, 1)))
      }
      
    }
    
    # print the mean of the checked Spiked blank if the column is there
    if(paste0('RPD.SB.',a)%in% colnames(qc_stats)){
      
      # FRANCES CHECK WHICH OF THESE WE WOULD HAVE FROM THE LIST ABOVE
      print(paste('mean percent difference from expected =', round(mean(unlist(c(qc_stats[paste0("RPD.SB.",a)]))), 1)))
    }
    
    print(paste('std dev =', round(sd(unlist(c(qc_stats[paste0("Conc.ugL.",a)]))),2)))
    
  } # end for loop the summary stats
  
  View(qc_stats)
  
  #summary of qc_stats$conc won't be super meaningful for check standards since there are multiple expected concentrations.
  #could potentially edit lines 71 and 89 to say if check != check standards then print the summary table?
  #same for lines that print standard deviation
  
  
  
  # make readline if statement based on the check
  
  if(check %in% 'water blank'){
    rl= readline('Review the water blanks- concentrations of digested blanks should be near zero. Do any lines need to be flagged? (y/n): ')
  } else if(check %in% 'digest check'){
    rl= readline('Review the digestion checks- concentrations should be near 40 ug P and 400 ug N. Do any lines need to be flagged? (y/n): ')
  } else if(check %in% 'spiked blank'){
    rl= readline('Review the spiked blanks- expected concentrations are shown. Do any lines need to be flagged? (y/n): ')
  } else if(check %in% 'check standards'){
    rl= readline('Review the check standards- target is <20% RPD for all but the lowest standards. Do any lines need to be flagged? (y/n): ')
  } else{
    warning("The check you put is not an option. The options are: water blank, digest check, spiked blank, check standards.")
  }
  
  
  while (rl=='y'|rl=='Y') {
    # can add more rows
    rn= readline('Enter the row number you want to flag (from row.number column; can enter multiple if they are all the same flag): ')
    
    var= readline('Which solutes needs to be flagged with the same number? (TN, TP, NH4, PO4, NO3): ')
    # make into a character vector
    
    print(flags)
    f = as.numeric(readline('Enter the flag number, as long as it is the same for all (see list above): '))
    note = as.character(readline('Enter a comment for the Notes column: '))
    
    # add in the flag and notes function here. This should work for everything and do not need to write everything again and again. 
    
    lachat_data <- append_flag_note(df = lachat_data, rn = rn, analyte = var, flag_num = f, note_text = note)
    
    
    # Make the lachat_data frame again and check you have flagged all the bad blanks
    wb <- lachat_data|>
      filter(grepl(all_name, Sample.ID,ignore.case = T))|>
      select(row.numbers, Cup.Number, Sample.ID, Detection.Time, we)
    
    # look at the data frame again
    View(wb)
    
    rl= readline('Are any more flags needed? (y/n): ')
  } 
  
  # make the qc_stats data frame after adding comments. 
  qc_stats2 <- lachat_data|>
    filter(grepl(all_name, Sample.ID,ignore.case = T) & Cup.Number!="S3")|>
    select(row.numbers, Detection.Date, Detection.Time, Sample.ID, Cup.Number, we)
  
  if(any(c("NH4", "PO4", "NO3") %in% analyte) & check %in% 'water blank'){
    qc_stats2 <- qc_stats2|>
      filter(Cup.Number %in% "S6")
  }
  
  # For check standards filter the data frame by Sample.Type instead of Sample.ID
  
  if(check %in% 'check standards'){
    qc_stats2 <- lachat_data |>
      filter(grepl("che", Sample.Type, ignore.case = T))|>
      select(row.numbers, Detection.Date, Detection.Time, Sample.ID, Cup.Number, we)
  }
  
  # Return two data frames. The data and the checks
  
  df <- list(lachat_data, qc_stats2)
  
  print(paste0("Flagged ", check, " in the data frame.")) 
  
  return(df)
  
  
}

