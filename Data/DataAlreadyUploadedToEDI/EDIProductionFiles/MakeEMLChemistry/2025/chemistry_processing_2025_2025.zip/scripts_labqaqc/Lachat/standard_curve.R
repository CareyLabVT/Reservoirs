standard_curve <- function(
    analyte,
    lachat_data){
  
# # test the function
#analyte = "TP"
#lachat_data = data


# print a plot. Add and interactive plot here with 

# have to figure out how to give a new symbol for the later check

# add titles and make labels flexible    
  
b <- lachat_data|>
  filter(grepl('Standard', Sample.Type))|>
  ggplot(aes(x = .data[[paste0("Peak.Area.",analyte)]], y = .data[[paste0("expected.conc.",analyte)]], color= as.factor(Sample.Type), text = row.numbers))+
  geom_point()+
  ggtitle(paste0("Original Standard Curve for ", analyte))
  theme_bw()+
  theme(element_text(size = 18))


png("preliminary_plots/standard_curve_plot_1.png", width = 10, height = 10,
    units = "in", res=600)
plot(b)
dev.off()



# add interactive plot to remove points

## ABP question. Do you need to be able to remove points in the standards curve? 
# In the plotly added row numbers so they can be easily identified and remove bad obs if necessary. 

print("Look at the plot of the standard curve in the Standard Curve Plots folder. The first one is labeled standard_curve_plot_1.")

rl= readline(paste0('Compare the curves for'," ", analyte ,'. Do you need to apply a different standard curve for'," ",analyte, '? (y/n): '))


#if needed, apply a weighted second order polynomial regression based on a later set of standards:

#someday add capacity for outlier removal to this section

if (rl=='y'|rl=='Y') {
  
  #Ask Claude how to turn this into a while loop to cycle through line 51 until rl=1 or rl=2
  #or just add some sort of check for an input that isn't 1 or 2

  rl= readline('Do you want to apply the new curve to the entire run (1) or a segment of the run (2)?: ')
  
  if (rl==1){
    rl= 'n'
    while (rl=='n'|rl=='N') {
      
      # make a smaller data frame for viewing
      small_df_l <- lachat_data|>
        select(Detection.Time, Sample.ID, Sample.Type, starts_with("peak"), starts_with("expec"))
      
      View(small_df_l) # which data set is this the standards or the lachat data set?
      start= as.numeric(readline('Enter the row number where the new standard curve starts: '))
      end= as.numeric(readline('Enter the row number where the new standard curve ends: '))
      
      new.stds= lachat_data[start:end,]
      
      # Add 0.3 to all observations because zeros don't work in the weighted regression
      new.stds[,paste0("expected.conc.",analyte)] <- new.stds[,paste0("expected.conc.", analyte)] + 0.3
      
      # Make a plot of the new checks with the polynomial curve
      plot <- ggplot(new.stds, aes(x=.data[[paste0("Peak.Area.",analyte)]], y=.data[[paste0("expected.conc.",analyte)]])) + 
        geom_point() +
        geom_smooth(method = 'lm', formula = y~poly(x,2)) +
        labs(title = paste0(analyte,' Calibration Curve (line is an estimate; weights not applied)'), 
             x= 'Peak Area', 
             y= 'Concentration (ppb)') + 
        theme_bw() +
        theme(element_text(size = 18))
      
      png("preliminary_plots/polynomial_curve_plot_2.png", width = 10, height = 10,
          units = "in", res=600)
      plot(plot)
      dev.off()
      
      print("Look at the Plot of the new ploynomial regression in the Standard Curve Plots folder. The second one is labele polymonial_curve_plot_2.")
      
      rl= readline('Is this the curve you want to apply? (y/n): ')
    }
    
    # this is a data frame. Make it into a list of values
    x <- new.stds[[paste0("Peak.Area.",analyte)]]
    
    pconc <- new.stds[[paste0("expected.conc.", analyte)]]
    
    
    p.reg= lm(pconc ~ poly(x, 2, raw=TRUE) , weights = 1/pconc)
    
    # check this out 
    # updating the observations 
    lachat_data[,paste0("Conc.ugL.",analyte)]= p.reg$coefficients[3]*(lachat_data[,paste0("Peak.Area.",analyte)]^2) + p.reg$coefficients[2]*lachat_data[,paste0("Peak.Area.",analyte)] + p.reg$coefficients[1]
    
    
    # Flag all the observations that were changed
    lachat_data[,paste0("Flag.",analyte)] = 1
    lachat_data[,paste0("Notes.",analyte)] = readline('Enter a note for the notes column (e.g., Used middle/final curve for calibration): ')
    # still need to fix this so we can make it flexible to select the analyte
    
    # mark the start and end points for the revised calibration in the flag column
    # the start of the revised calibration
    lachat_data[start,paste0("Notes.",analyte)]= paste0(lachat_data[start,paste0("Notes.",analyte)], '. Start point for revised calibration.')
    
    #the end of the revised calibration
    lachat_data[end,paste0("Notes.",analyte)]= paste0(lachat_data[end,paste0("Notes.",analyte)], '. End point for revised calibration.')
  }

  
  #ERRORS IN THE RL==2 SECTION BELOW- LINES FOR ADDING NOTES DON'T WORK. SAME <CHARACTER> VERSUS <DOUBLE> ISSUE WE'VE HAD BEFORE.
  
  if (rl==2){
    rl= 'n'
    while (rl=='n'|rl=='N') {
      
      # make a smaller data frame for viewing
      small_df_l <- lachat_data|>
        select(Detection.Time, Sample.ID, Sample.Type, starts_with("peak"), starts_with("expec"))
      
      View(small_df_l) # which data set is this the standards or the lachat data set?
      start= as.numeric(readline('Enter the row number where the new standard curve starts: '))
      end= as.numeric(readline('Enter the row number where the new standard curve ends: '))
      
      new.stds= lachat_data[start:end,]
      
      # Add 0.3 to all observations because zeros don't work in the weighted regression
      new.stds[,paste0("expected.conc.",analyte)] <- new.stds[,paste0("expected.conc.", analyte)] + 0.3
      
      # Make a plot of the new checks with the polynomial curve
      plot <- ggplot(new.stds, aes(x=.data[[paste0("Peak.Area.",analyte)]], y=.data[[paste0("expected.conc.",analyte)]])) + 
        geom_point() +
        geom_smooth(method = 'lm', formula = y~poly(x,2)) +
        labs(title = paste0(analyte,' Calibration Curve (line is an estimate; weights not applied)'), 
             x= 'Peak Area', 
             y= 'Concentration (ppb)') + 
        theme_bw() +
        theme(element_text(size = 18))
      
      png("preliminary_plots/polynomial_curve_plot_2.png", width = 10, height = 10,
          units = "in", res=600)
      plot(plot)
      dev.off()
      
      print("Look at the Plot of the new ploynomial regression in the Standard Curve Plots folder. The second one is labele polymonial_curve_plot_2.")
      
      rl= readline('Is this the curve you want to apply? (y/n): ')
    }
    
    # this is a data frame. Make it into a list of values
    x <- new.stds[[paste0("Peak.Area.",analyte)]]
    
    pconc <- new.stds[[paste0("expected.conc.", analyte)]]
    
    p.reg= lm(pconc ~ poly(x, 2, raw=TRUE) , weights = 1/pconc)
    
    lachat_data[,paste0("Notes.",analyte)]= as.character(lachat_data[,paste0("Notes.",analyte)])
    
    #select the subset of rows you want to apply the new curve to
    View(small_df_l)
    data.start <- as.numeric(readline("Enter the row number where you want to start applying the new curve: "))
    data.end   <- as.numeric(readline("Enter the row number where you want to stop applying the new curve: "))
    for (i in data.start:data.end) {
      #apply revised calibration to selected rows
      lachat_data[i,paste0("Conc.ugL.",analyte)]= p.reg$coefficients[3]*(lachat_data[i,paste0("Peak.Area.",analyte)]^2) + p.reg$coefficients[2]*lachat_data[i,paste0("Peak.Area.",analyte)] + p.reg$coefficients[1]
      # Flag all the observations that were changed
      lachat_data[i,paste0("Flag.",analyte)] = 1
      lachat_data[i,paste0("Notes.",analyte)] = 'Applied alternate standard curve.'
    }

    # mark the start and end points for the revised calibration in the flag column
    # the start of the revised calibration
    lachat_data[start,paste0("Notes.",analyte)]= paste0(lachat_data[start,paste0("Notes.",analyte)], '. Start point for revised calibration.')
    
    #the end of the revised calibration
    lachat_data[end,paste0("Notes.",analyte)]= paste0(lachat_data[end,paste0("Notes.",analyte)], '. End point for revised calibration.')
    
    #clean up nonsense from how i converted the type to character:
    for (i in 1:nrow(lachat_data)) {
      if (i<data.start) {lachat_data[i,paste0("Notes.",analyte)] = NA}
      if (i>data.end) {lachat_data[i,paste0("Notes.",analyte)] = NA}
    }
  }
  
  
}

View(lachat_data)
rl= readline(paste0('Do you need to add any additional notes or flags for ', analyte, ' standards?'," ", '(y/n): '))

while (rl=='y'|rl=='Y') {
  # can add more rows
  rn= readline('Enter the row number you want to flag (from row.number column; can enter multiple if they are all the same flag): ')
  
  print(flags)
  f= as.numeric(readline('Enter the flag number, as long as it is the same for all (see list above): '))
  note= as.character(readline('Enter a comment for the Notes column: '))
  
  # add in the flag and notes function here. This should work for everything and do not need to write everything again and again. 
  
  lachat_data <- append_flag_note(df = lachat_data, rn = rn, analyte = analyte, flag_num = f, note_text = note)
  
  # look at the data frame again
  View(lachat_data)
  
  rl= readline('Are any more flags needed? (y/n): ')
} 


# Need to return the updated data frame
return(lachat_data)

}


# # test function here
# standard_curve(
#    analyte = "TP",
#    lachat_data = data)
