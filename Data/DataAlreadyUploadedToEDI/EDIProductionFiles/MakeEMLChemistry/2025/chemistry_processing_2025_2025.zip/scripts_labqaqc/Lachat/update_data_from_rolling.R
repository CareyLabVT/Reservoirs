# Fix with code from CLAUDE

# Title: update_data_from_rolling.R
# After run_mdl_rolling_charts() completes and charts are saved, pull back any
# flags/notes that were added or changed during the rolling-chart interactive
# review and apply them to the corresponding rows in the main lachat data frame.
#
# Why this is needed:
#   qc_check()          → flags rows in lachat_data based on the current run
#   add_rollingcharts() → appends current-run check rows to the historic rolling file
#   run_mdl_rolling_charts() → may add *additional* flags during the rolling-chart
#                              review (e.g. flagging a point that looks like an
#                              outlier only in the context of the full history)
#   This function propagates those additional rolling-chart flags back into the
#   main lachat data frame so the final exported run file is complete.
#
# Arguments:
#   lachat_data    - the main run data frame (typically data_list[[1]] returned
#                   by qc_check())
#   rolling_export - the data frame returned by run_mdl_rolling_charts()
#                   (contains the full rolling chart history with updated flags)
#   run_date       - Detection.Date for the current run as a character or Date
#                   (e.g. runDate). Used to identify the newest rows in the
#                   rolling chart.
#   analytes       - character vector of analytes, e.g. c("TN", "TP")
#
# Returns:
#   lachat_data with Flag.* and Notes.* updated for every row that appears in
#   the current-run slice of the rolling chart.  Rows that are not part of the
#   rolling chart (e.g. unknown samples) are returned unchanged.
#
# Matching key:  Detection.Date + Sample.ID + Cup.Number
#   Both columns are normalised to character before joining so that type
#   differences between the raw CSV and the rolling chart do not cause
#   silent non-matches.

update_data_from_rolling <- function(
    lachat_data,
    rolling_export,
    #run_date,
    analytes = c("TN", "TP")
) {
  
  # lachat_data = data_blank
  # rolling_export = rolling_chart
  # #run_date,
  # analytes = c("TN", "TP")
  
  # run_date_parsed <- tryCatch(
  #   # find the data in the data_file
  #   data_file[[1, "Detection.Date"]],
  #   error = function(e) as.Date(run_date, tryFormats = c("%Y-%m-%d", "%m/%d/%Y"))
  # )
  
  # ^^^this version has been causing problems when Frances tries to run it

  run_date_parsed= as.Date(runDate)   #if you trust yourself to type the date correctly you can do this way
  
  # -------------------------------------------------------------------------
  # 1. Isolate only the rows from the current run
  # -------------------------------------------------------------------------
  new_obs <- rolling_export |>
    dplyr::filter(as.Date(Detection.Date) == run_date_parsed)
  
  if (nrow(new_obs) == 0) {
    message("update_data_from_rolling: no rows in the rolling chart match run date ",
            run_date_parsed, ". Returning lachat_data unchanged.")
    return(lachat_data)
  }
  
  # -------------------------------------------------------------------------
  # 2. Build a lookup table: join key + updated flag/notes columns
  # -------------------------------------------------------------------------
  flag_note_cols <- unlist(lapply(c("Flag.", "Notes."), paste0, analytes))
  
  # ensure flag/note columns are character in both data frames
  for (col in flag_note_cols) {
    if (col %in% colnames(lachat_data))  lachat_data[[col]]  <- as.character(lachat_data[[col]])
    if (col %in% colnames(new_obs))      new_obs[[col]]      <- as.character(new_obs[[col]])
  }
  
  
  # keep only columns we need and normalise join-key types to character
  lookup <- new_obs |>
    dplyr::mutate(
      .join_date   = as.character(as.Date(Detection.Date)),
      .join_sample = as.character(Sample.ID),
      .join_cup    = as.character(Cup.Number),
      .join_time = as.numeric(Detection.Time)
    ) |>
    dplyr::select(.join_date, .join_sample, .join_cup,.join_time,
                  dplyr::all_of(flag_note_cols)) |>
    dplyr::distinct() |>
    # prefix the flag/notes columns so they do not collide with lachat_data columns
    dplyr::rename_with(~ paste0(".rc_", .), dplyr::all_of(flag_note_cols))
  
  rc_cols <- paste0(".rc_", flag_note_cols)
  
  # -------------------------------------------------------------------------
  # 3. Join the lookup into lachat_data and update Flag/Notes columns
  #    coalesce(rolling_chart_value, existing_value):
  #      - rolling chart has a value → use it (may have extra flags added
  #        during the rolling-chart review on top of qc_check flags)
  #      - rolling chart has NA (row not in rolling chart) → keep existing value
  # -------------------------------------------------------------------------
  lachat_data <- lachat_data |>
    dplyr::mutate(
      .join_date   = as.character(as.Date(Detection.Date,
                                          tryFormats = c("%Y-%m-%d", "%m/%d/%Y"))),
      .join_sample = as.character(Sample.ID),
      .join_cup    = as.character(Cup.Number),
      .join_time = as.numeric(Detection.Time),
      
    ) |>
    dplyr::left_join(
      lookup,
      by = c(".join_date", ".join_sample", ".join_cup", ".join_time")
    )
  
  for (col in flag_note_cols) {
    rc_col <- paste0(".rc_", col)
    
    if (rc_col %in% colnames(lachat_data)) {
      lachat_data[[col]] <- dplyr::coalesce(lachat_data[[rc_col]],
                                            lachat_data[[col]])
      lachat_data[[rc_col]] <- NULL
    }
  }
  
  # remove temporary join-key columns
  lachat_data <- lachat_data |>
    dplyr::select(-.join_date, -.join_sample, -.join_cup, -.join_time)
  
  message("update_data_from_rolling: merged rolling-chart flags/notes back into ",
          "lachat_data for ", run_date_parsed,
          " (", nrow(new_obs), " observation(s) matched).")
  
  return(lachat_data)
}
