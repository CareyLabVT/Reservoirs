# Adapted from the chla processing L1 script
# Written 26 Jun 2026
# By Katie Hoffman

# Things the script does: 
# 1. Read in Maintenance log and read in raw TICTOC files
# 2. Applies the maintenance log to the TICTOC runs
# 3. Outputs TICTOC data post maintenance log (removes any erroneous injections, bad samples, 
# renumbers samples if necessary, etc.)

# right now this will only address analytes all at once or as a group 
# (both mg/L and area for a given analyte will be updated)

TICTOC_applymaintlog <- function(maintenance_file,  
                                 directory, #this is the folder where all of the TICTOC runs are stored
                                 outfile = TICTOC_postmaintlog.csv,
                                 start_date = NULL,
                                 end_date = NULL, 
                                 outputcheck_folder = paste0(here()))
{
  # maintenance_file = paste0(here(), "/maintenance_logs/TICTOC_maintlog.csv")
  # directory = paste0(here(), "/Raw/TICTOC")
  # outfile = paste0(here(), "/Results/TICTOC")
  # start_date = NULL
  #  end_date = NULL
  # outputcheck_folder = paste0(here())
  
  #packages
  pacman::p_load(tidyverse, gsheet, arsenal, here)
  
  
  #create the output check folder. You will look in this folder to check for issues.
  if(!file.exists(outputcheck_folder)){
    #make the folder
    dir.create(file.path(outputcheck_folder))
  }
  
  #### 1. Read in Maintenance file and the Raw files from the spec 
  ### 1.1 Read in Maintenance file #### 
  
  
  ## check how maintenance log is read in/entered
  log_read <- read_csv(maintenance_file, col_types = cols(
    .default = col_character(),
    date_run = col_date("%Y-%m-%d"),
    lab_flag = col_integer()))
  
  print(("Warning! the following rows from the maintenance log may cause you trouble. Do you have something other than NA or a date in the SampleDate column?"))
  
  print(problems(log_read))
  write.csv(log_read, paste0(outputcheck_folder, "/maintlog_problems.csv"))
  
  read_raw_tictoc_files <- function(FILES){
    
    # print file names to see where errors occur
    print(paste0("Read in ", FILES))
    
    # Get the date the samples were processed
    Date <- str_extract(basename(FILES), "^\\d+")
    
    # Put the date in the proper format
    Date_processed <- as.Date(Date, "%Y%m%d")
    
    # read in the files
    data <- read_csv(FILES, show_col_types = FALSE, skip = 1) |>
      janitor::clean_names()
    
    # Add the date processed to the files
    data$Date_processed <- Date_processed
    
    return(data)
  }
  
  # Use the function to make a data frame of all samples
  # use purr to read in all the files using the function above
  files<-list.files(path= directory, pattern=".csv", full.names=TRUE)
  
  if(length(files)==0){
    
    warning("There are no text files in the directory you listed")
    
  }else{
    out.file <- files|>
      map_df(~ read_raw_tictoc_files(.x)) # read in files and bind them together
  }
  
  
  ### 4. Take out values based on the Maintenance Log 
  
  print("Take and flag values in the maintenance log")
  
  # filter out the samples based on start and end date
  if(!is.null(end_date)){
    # get the the last date the samples were processed
    
    processed_date_max <- out.file|>
      filter(Sample_date<= end_date)|>
      pull(Date_processed)|>
      max()
    
    
    out.file <- out.file |>
      filter(Date_processed <= processed_date_max)
  }

  
  if(!is.null(start_date)){
    
    # get
    processed_date_min <- out.file|>
      filter(Sample_date >= start_date)|>
      pull(Date_processed)|>
      min()
    
    
    comb2 <- out.file |>
      filter(Date_processed >= processed_date_min)
  }
  
  
  ## Define Maintenance Flags HERE:
  
  # Add Flag columns
  
  raw_df<-out.file %>%
    mutate(
      lab_flag  = 0
    )
  
  ## Define Maintenance Flags HERE:
  
  # Add Flag columns
  
  raw_df <- out.file %>%
    mutate(
      lab_flag = 0
    )
  
  ### 4.1 Set up the Values to be used 
  log <- read.csv(maintenance_file)
  
  if(nrow(log) > 0){
    
    for(i in 1:nrow(log)){
      
      ### Get the date the samples were processed
      date_run <- log$date_run[i]
      
      ### Get the name
      name <- log$name[i]
      
      ### Get the line number
      line_no <- log$line_no[i]
      
      ### Get the hole position
      hole_pos <- log$hole_pos[i]
      
      ### Get the Maintenance Flag 
      flag <- log$lab_flag[i]
      
      ### Columns that hold analytical results, grouped by analyte
      data_cols_all <- c("tic_area", "tc_area", "npoc_area", "t_nb_area",
                         "tic_mg_l", "tc_mg_l", "toc_diff_mg_l", 
                         "npoc_mg_l", "t_nb_mg_l")
      
      data_cols_tic <- c("tic_area", "tic_mg_l")
      
      data_cols_tc  <- c("tc_area", "tc_mg_l", "toc_diff_mg_l")
      
      data_cols_tnb <- c("t_nb_area", "t_nb_mg_l")
      
      ### Get the analyte from the maintenance log
      analyte <- log$analyte[i]
      
      ### Select columns based on analyte
      affected_cols <- if(analyte == "all"){
        data_cols_all
      } else if(analyte == "tic"){
        data_cols_tic
      } else if(analyte == "tc"){
        data_cols_tc
      } else if(analyte == "tnb"){
        data_cols_tnb
      } else {
        warning("Analyte not recognized. Check maintenance log.")
        next
      }
      
      ### Flag column
      flag_cols <- "lab_flag"
      
      ### Match rows in raw_df to the maintenance log entry
      sample_match <- raw_df$Date_processed == as.Date(date_run) &
        raw_df[, "name"]     == name &
        raw_df[, "no"]  == line_no &
        raw_df[, "hole_pos"] == hole_pos
      
      ### 4.2 Actually apply maintenance log changes
      if(flag == 1){
        # Set specific line to NA
        raw_df[which(sample_match), affected_cols] <- NA
        raw_df[which(sample_match), flag_cols]     <- flag
        
      } else if(flag == 2){
        # do nothing, just flag
        raw_df[which(sample_match), flag_cols] <- flag
        
      } else if(flag == 3){
        # high concentration in blanks - do nothing, just flag
        raw_df[which(sample_match), flag_cols] <- flag
        
      } else if(flag == 4){
        # poor recovery - do nothing, just flag
        raw_df[which(sample_match), flag_cols] <- flag
        
      } else if(flag == 5){
        # high relative percent difference - do nothing, just flag
        raw_df[which(sample_match), flag_cols] <- flag
        
      } else if(flag == 6){
        # bad integration - do nothing, just flag
        raw_df[which(sample_match), flag_cols] <- flag
        
      } else if(flag == 7){
        # out of range - do nothing, just flag
        raw_df[which(sample_match), flag_cols] <- flag
        
      } else if(flag == 8){
        # wrong in some way - set to NA and flag
        raw_df[which(sample_match), affected_cols] <- NA
        raw_df[which(sample_match), flag_cols]     <- flag
        
      } else if(flag == 9){
        # use with caution - do nothing, just flag
        raw_df[which(sample_match), flag_cols] <- flag
        
      } else {
        warning("Flag used not defined in the script. Just making up numbers now?")
      }
    }
    
  } else {
    print("No items in the maintenance log during the current period. If you expect items in the maintenance log, stop and check the maintenance log and script.")
  }
  
  
  # subset to make the L1 file. Maybe look at moving this earlier. 
  
  # Start with raw_df as the base
  final <- raw_df
  
  if(!is.null(start_date)){
    start_date <- as.Date(start_date)
    final <- final %>%
      filter(Date_processed >= start_date)
  }
  
  if(!is.null(end_date)){
    end_date <- as.Date(end_date)
    final <- final %>%
      filter(Date_processed <= end_date)
  }
  
  # if (!is.null(start_date)){
  #   #force tz check
  #   start_date <- force_tz(as.POSIXct(start_date), tzone = "America/New_York")
  #   
  #   raw_df$DateTime <- as.character(format(raw_df$DateTime)) # convert DateTime to character
  #   
  #   final <- raw_df %>%
  #     filter(DateTime >= start_date)
  #   
  # }
  # 
  # if(!is.null(end_date)){
  #   #force tz check
  #   end_date <- force_tz(as.POSIXct(end_date), tzone = "America/New_York")
  #   
  #   raw_df$DateTime <- as.character(format(raw_df$DateTime)) # convert DateTime to character
  #   
  #   final <- raw_df %>%
  #     filter(DateTime <= end_date)
  #   
  # }
  # 
  # Check if there are any files for the L1. If not then end the script
  
  if(nrow(final)==0){
    
    print("No new files for the current year")
    
  }else{
    
    
    ### 7. Save the file. If outfile is NULL then return the file
    
    if(is.null(outfile)){
      
      return(final)
    }else{
      
      write_csv(final, outfile)
    }
    
  } # ends the if statement if there are no new observations
  
} # ends the function

